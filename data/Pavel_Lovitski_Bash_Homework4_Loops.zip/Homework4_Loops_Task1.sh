#!/bin/bash

seq --separator=' ' 1 10  	#use option -s to separate numbers 
