#!/bin/bash

echo {20..-20..4}  #output from 20 to -20 with step 4
