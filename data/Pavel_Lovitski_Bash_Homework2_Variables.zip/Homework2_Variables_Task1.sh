#!/bin/bash

#create variables for task
var1=$(date)
var2="Hello, task2!"

#print output
echo "[$var1] $var2" 


