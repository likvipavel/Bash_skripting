#!/bin/bash

echo ${MY_VAR-default}  #print the result of "default", if variable $MY_VAR is unset
