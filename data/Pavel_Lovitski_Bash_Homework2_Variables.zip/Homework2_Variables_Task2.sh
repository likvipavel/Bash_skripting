#!/bin/bash

var1="Hello, "
var2="broken"
var3="skript!"
printf "%s %s %s\n" $var1 $var2 $var3 #'%f %d' not needed in this task; added '\n' for line break
